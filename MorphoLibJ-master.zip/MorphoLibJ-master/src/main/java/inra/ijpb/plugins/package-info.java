/**
 * <p>Contains plugins, for integration with ImageJ GUI.</p>
 * 
 * <p>The file defining the plugin arborescence in menu is located in 
 * <code>src/main/resources/plugins.config</code>.</p>
 */
package inra.ijpb.plugins;


