/**
 * Morphological directional filters.
 * 
 * @author dlegland
 *
 */
package inra.ijpb.morphology.directional;