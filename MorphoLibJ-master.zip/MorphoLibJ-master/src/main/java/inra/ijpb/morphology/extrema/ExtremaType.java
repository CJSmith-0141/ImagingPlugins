/**
 * 
 */
package inra.ijpb.morphology.extrema;

/**
 * One of the two types of extrema.
 */
public enum ExtremaType {
	MINIMA, 
	MAXIMA;
}
