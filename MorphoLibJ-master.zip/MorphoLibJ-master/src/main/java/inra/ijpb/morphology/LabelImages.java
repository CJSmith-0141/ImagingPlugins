package inra.ijpb.morphology;

/**
 * @deprecated as from 2014.11.03, replaced by class inra.ijpb.label.LabelImages
 */
@Deprecated
public class LabelImages extends inra.ijpb.label.LabelImages {
	/**
	 * Private constructor to prevent class instantiation.
	 */
	private LabelImages()
	{
	}


}
