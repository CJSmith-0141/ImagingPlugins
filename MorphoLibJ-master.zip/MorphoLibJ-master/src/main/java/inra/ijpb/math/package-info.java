/**
 * Some math operators for images that do not need calling ImageJ plugins. 
 * 
 * @author David Legland
 *
 */
package inra.ijpb.math;