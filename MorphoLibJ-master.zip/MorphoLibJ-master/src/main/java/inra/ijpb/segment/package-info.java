/**
 * Aims at gathering various segmentation algorithms. Contains only threshold utility.
 * 
 * @author David Legland
 *
 */
package inra.ijpb.segment;