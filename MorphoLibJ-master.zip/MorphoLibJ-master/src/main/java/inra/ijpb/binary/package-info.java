/**
 * <p>Operators taking binary images as input, such as connected component
 * labeling or distance maps.</p>
 * 
 */
package inra.ijpb.binary;


