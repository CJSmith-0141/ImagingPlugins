/**
 * <p>Algorithms for computing geodesic distances, geodesic diameters, tortuosity...</p>
 */
package inra.ijpb.binary.geodesic;


