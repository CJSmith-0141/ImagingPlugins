/**
 * Utility methods for label images (stored as 8-, 16- or 32-bits).
 */
package inra.ijpb.label;


