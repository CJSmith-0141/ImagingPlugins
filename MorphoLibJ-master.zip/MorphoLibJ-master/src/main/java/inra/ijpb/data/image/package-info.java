/**
 * <p>Some classes to access image data in a unified and hopefully efficient way.</p>
 */
package inra.ijpb.data.image;


