/**
 * <p>Some utility classes for accessing image data.</p>
 */
package inra.ijpb.data;


