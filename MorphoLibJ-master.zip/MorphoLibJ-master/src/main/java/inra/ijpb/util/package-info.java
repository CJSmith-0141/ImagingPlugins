/**
 * <p>Various utility classes (colors, gui utils...).</p>
 */
package inra.ijpb.util;


