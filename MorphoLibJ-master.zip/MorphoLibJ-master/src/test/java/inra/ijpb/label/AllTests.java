package inra.ijpb.label;


import inra.ijpb.label.LabelImagesTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	// generic classes
	LabelImagesTest.class, 
	})
public class AllTests {
  //nothing
}
