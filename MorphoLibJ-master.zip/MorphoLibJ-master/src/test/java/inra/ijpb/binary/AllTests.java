package inra.ijpb.binary;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	// generic classes
	BinaryImagesTest.class, 
	})
public class AllTests {
  //nothing
}
