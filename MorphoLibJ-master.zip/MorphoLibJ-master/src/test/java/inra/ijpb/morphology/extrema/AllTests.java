package inra.ijpb.morphology.extrema;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	// generic classes
	RegionalExtrema3DByFloodingTest.class,
	RegionalExtremaByFloodingTest.class
	})
public class AllTests {
  //nothing
}
