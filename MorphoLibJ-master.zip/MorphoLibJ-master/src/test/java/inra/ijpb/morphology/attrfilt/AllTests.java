package inra.ijpb.morphology.attrfilt;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	// generic classes
	AreaOpeningQueueTest.class,
	SizeOpening3DQueueTest.class,
	})
public class AllTests {
  //nothing
}
